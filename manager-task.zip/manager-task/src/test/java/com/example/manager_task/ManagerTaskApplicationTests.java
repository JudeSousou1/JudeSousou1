package com.example.manager_task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagerTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
