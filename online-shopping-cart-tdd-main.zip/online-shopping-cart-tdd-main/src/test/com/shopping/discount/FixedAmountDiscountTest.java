package com.shopping.discount;

import static org.junit.jupiter.api.Assertions.*;

class FixedAmountDiscountTest {

}