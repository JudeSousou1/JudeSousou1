package com.shopping.model;

import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

}