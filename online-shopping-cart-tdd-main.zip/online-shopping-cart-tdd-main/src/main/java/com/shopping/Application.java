package com.shopping;

public class Application {
}
