package com.shopping.model;

public class Product {
}
