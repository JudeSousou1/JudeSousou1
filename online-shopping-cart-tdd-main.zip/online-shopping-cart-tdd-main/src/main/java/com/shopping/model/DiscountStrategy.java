package com.shopping.model;

public class DiscountStrategy
{
}
