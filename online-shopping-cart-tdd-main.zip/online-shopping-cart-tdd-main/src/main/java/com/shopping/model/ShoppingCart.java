package com.shopping.model;

public class ShoppingCart {
}
