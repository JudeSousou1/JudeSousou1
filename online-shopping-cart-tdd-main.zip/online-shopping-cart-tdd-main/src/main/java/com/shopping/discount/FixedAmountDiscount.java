package com.shopping.discount;

public class FixedAmountDiscount {
}
