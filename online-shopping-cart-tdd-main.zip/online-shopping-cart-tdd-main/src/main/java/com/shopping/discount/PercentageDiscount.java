package com.shopping.discount;

public class PercentageDiscount {
}
