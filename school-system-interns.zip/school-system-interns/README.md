# School System Intern Task

## Project Overview

Create a School System application that manages student and subject information using Java 8, Servlets, JSP, Object-Oriented Programming (OOP), JUnit for testing, Maven for project structure, and custom exceptions for error handling. Implement the solution using interfaces for better code organization.

## Entities

### Student

- Attributes: student name, student id, age, subjects, address, school name
- Methods:
  - `printInfo()`: Display student information
  - `addStudent()`: Add a new student (validated by unique student id)
  - `addSubjectToStudent()`: Add a subject to a student (validated by unique student id and subject id)
  - `editStudentInfo()`: Edit student information (validated by unique student id)
  - `removeStudent()`: Remove a student (validated by unique student id)

### Subject

- Attributes: subject name, subject id, teacher name, student count
- Methods:
  - `printInfo()`: Display subject information
  - `addSubject()`: Add a new subject (validated by unique subject id)
  - `editSubjectInfo()`: Edit subject information (validated by unique subject id)
  - `removeSubject()`: Remove a subject (validated by unique subject id)

### Exception Handling

Create custom exceptions for handling specific errors:

- `DuplicateIdException`: Thrown when a duplicate id is detected during adding.
- `RecordNotFoundException`: Thrown when a record is not found for editing or removal.

## Implementation Details

- Use interfaces (`StudentService`, `SubjectService`, etc.) to define the contract for different service implementations.
- Implement classes (`StudentServiceImpl`, `SubjectServiceImpl`) that implement these interfaces and handle business logic.
- Use Servlets to handle user requests and communicate with service implementations.
- Use JSP for rendering user interfaces.
- Implement validation checks for strings, integers, and unique IDs in service implementations.
- Organize the project structure using Maven conventions.
- Write JUnit tests for each service method to ensure their correctness.
- Utilize Java 8 features for streamlined coding.
- Implement a user interface where the user can choose between managing students and subjects, then select a method to perform.

## Tools and Technologies

- Java 8
- Servlets
- JSP
- Object-Oriented Programming
- JUnit
- Maven
- Custom Exception Handling
- Interfaces

By following this enhanced plan, the School System Intern task will be well-organized, maintainable, and efficient. It incorporates best practices for development, testing, and code structure, enhancing the overall quality of the solution.
