package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.subject.Subject;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class SubjectDeletionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int subjectId = Integer.parseInt(request.getParameter("SID"));


        Subject subject = Subject.getSubjectById(subjectId);

        Subject.removeSubject(subject);

        request.getRequestDispatcher("SubjectDeletion.jsp").forward(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
