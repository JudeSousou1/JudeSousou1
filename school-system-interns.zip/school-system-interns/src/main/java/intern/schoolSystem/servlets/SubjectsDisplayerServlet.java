package intern.schoolSystem.servlets;


import intern.schoolSystem.administration_system.subject.Subject;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class SubjectsDisplayerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String subjectName = request.getParameter("subjectName");
        String teacherName = request.getParameter("teacherName");
        int subjectId = Integer.parseInt(request.getParameter("subjectId"));
        int studentCount = Integer.parseInt(request.getParameter("studentCount"));
        String subjectString = request.getParameter("subjects");
        String[] subjectArray = subjectString.split(",");
        ArrayList<Subject> subjects = new ArrayList<>();
        for (int i = 0; i < subjectArray.length; i++) {
            subjects.add(Subject.valueOf(subjectArray[i]));
        }

        Subject subject = new Subject(subjectName, teacherName, subjectId, studentCount);

        subject.printInfo();

        try (PrintWriter out = response.getWriter()) {
            out.println(subject);
        } catch (NullPointerException | IllegalArgumentException | IOException ex) {

            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input: " + ex.getMessage());
        }
    }
}
