package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.address.Address;
import intern.schoolSystem.administration_system.student.Student;
import intern.schoolSystem.administration_system.subject.Subject;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class StudentsDisplayerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String schoolName = request.getParameter("schoolName");
        int id = Integer.parseInt(request.getParameter("id"));
        int age = Integer.parseInt(request.getParameter("age"));
        String subjectString = request.getParameter("subjects");
        String[] subjectArray = subjectString.split(",");
        ArrayList<Subject> subjects = new ArrayList<>();
        for (int i = 0; i < subjectArray.length; i++) {
            subjects.add(Subject.valueOf(subjectArray[i]));
        }
        Address address = Address.valueOf(request.getParameter("address"));

        Student student = new Student(name, id, schoolName, age, address, subjects);

        student.printInfo();

        try (PrintWriter out = response.getWriter()) {
            out.println(student);
        } catch (NullPointerException | IllegalArgumentException ex) {

            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input: " + ex.getMessage());
        }

    }
}
