package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.subject.Subject;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class SubjectEditServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String subjectName = request.getParameter("SubName");
        String teacherName = request.getParameter("teachName");
        String subjectId = request.getParameter("SUId");
        String studentCount = request.getParameter("STcount");

        Subject subject = Subject.getSubjectById(Integer.parseInt(subjectId));
        subject.editSubjectInfo(subjectName, Integer.parseInt(subjectId), Integer.parseInt(studentCount), teacherName);

        request.getRequestDispatcher("SubjectEdit.jsp").forward(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
