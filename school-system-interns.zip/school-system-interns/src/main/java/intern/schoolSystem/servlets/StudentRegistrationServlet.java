package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.address.Address;
import intern.schoolSystem.administration_system.student.Student;
import intern.schoolSystem.administration_system.subject.Subject;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;

public class StudentRegistrationServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("StudName");
        String schoolName = request.getParameter("schoolName");
        String id = request.getParameter("Sid");
        String age = request.getParameter("SAge");
        String subjectString = request.getParameter("Ssubject");
        String[] subjectArray = subjectString.split(",");
        ArrayList<Subject> subjects = new ArrayList<>();
        for (int i = 0; i < subjectArray.length; i++) {
            subjects.add(Subject.valueOf(subjectArray[i]));
        }

        Address address = Address.valueOf(request.getParameter("SAddress"));

        Student student = new Student(name, Integer.parseInt(id), schoolName,Integer.parseInt(age), address, subjects);
        request.getRequestDispatcher("StudentRegistration.jsp").forward(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
