package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.student.Student;
import intern.schoolSystem.administration_system.subject.Subject;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class EnrollOrDropSubjectServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        int subjectId = Integer.parseInt(request.getParameter("subjectId"));
        int id = Integer.parseInt(request.getParameter("Studid"));

        Student s = Student.getStudentById(id);
        Subject subject = Subject.getSubjectById(id);

        s.addSubjectToStudent(subject);

        request.getRequestDispatcher("EnrollOrDropSubject.jsp").forward(request, response);
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
