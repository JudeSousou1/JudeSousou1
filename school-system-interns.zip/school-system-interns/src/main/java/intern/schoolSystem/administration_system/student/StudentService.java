package intern.schoolSystem.administration_system.student;

interface StudentService {
    public void StudentServiceImpl();
}
