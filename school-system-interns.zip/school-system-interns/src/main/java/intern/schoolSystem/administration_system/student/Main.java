package intern.schoolSystem.administration_system.student;

import intern.schoolSystem.administration_system.address.Address;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //Student student = new Student();
//        student.setName("John Doe");
//        student.setAge(19);
//        student.setId(17);
//        Address address = new Address("K90L03", "Street 1", 21 );
//        student.setAddress(address);
//        ArrayList<Student> students = new ArrayList<Student>();
//        //students.add(student);
//        student.setStudents(students);
//        student.addStudent(student);


//        Student student2 = new Student();
//        student2.setName("Bob Lee");
//        student2.setAge(21);
//        student.setId(102);
//        students.add(student2);
//        student.setStudents(students);
//        Address address3 = new Address("O72L10", "Street 3", 90);
//        student2.setAddress(address3);


//        Student student3 = new Student();
//        student3.setName("Jane Doe");
//        student3.setAge(22);
//        student3.setId(103);
//        Address address2 = new Address("JS9021", "Street 2", 21 );
//        student3.setAddress(address2);
//        student3.addStudent(student3);
//        for (Student stud : students) {
//            stud.printInfo();
//        }

//        student.removeStudent(student2);
//        student3.printInfo();
    }
}
