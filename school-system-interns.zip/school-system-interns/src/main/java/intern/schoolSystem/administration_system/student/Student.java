package intern.schoolSystem.administration_system.student;

import intern.schoolSystem.administration_system.DuplicateIdException;
import intern.schoolSystem.administration_system.RecordNotFoundException;
import intern.schoolSystem.administration_system.address.Address;
import intern.schoolSystem.administration_system.subject.Subject;

import java.util.ArrayList;
import java.util.Arrays;

public class Student {
    private String name;
    private int id;
    private int age;
    private String schoolName;
    private Address address;
    private static ArrayList<Student> students = new ArrayList<Student>();
    private ArrayList<Subject> subjects = new ArrayList<Subject>();


    public Student(String name, int id, String schoolName, int age, Address address, ArrayList<Subject> subjects) {
        this.name = name;
        this.id = id;
        this.schoolName = schoolName;
        this.age = age;
        this.address = address;
        this.subjects = subjects;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        Student.students = students;
    }

    public void printInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("School Name: " + schoolName);
        System.out.println("Address: " + address.toString());
        System.out.print("Students: ");
        for (Student s : students) {
            System.out.print(s.getName() + " , ");
        }
        System.out.println("\n");
    }

    public static void addStudent(Student student) {
        for (Student s : students) {
            if (student.getId() == s.getId()) {
                throw new DuplicateIdException("ID already exists");
            }
        }
        students.add(student);
    }

    public void addSubjectToStudent(Subject subject) {
        for (Subject s : subjects) {
            if (s.getId() == subject.getId()) {
                throw new DuplicateIdException("ID already exists");
            }
        }
        subjects.add(subject);
    }


    public void editStudentInfo(int id, String name, int age, String schoolName, Address address) {
        boolean found = false;
        for (Student s : students) {
            if (id == s.getId()) {
                this.setName(name);
                this.setAge(age);
                this.setSchoolName(schoolName);
                this.setAddress(address);
                found = true;
            }
        }
        if (!found) {
            throw new RecordNotFoundException("Record not found");
        }

    }

    public static Student getStudentById(int id) {
        for (Student s : students) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    public static void removeStudent(int id) {
        boolean found = false;
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId() == id) {
                students.remove(i);
                found = true;
            }
        }
        if (!found) {
            throw new RecordNotFoundException("Record does not exist");
        }
    }

}
