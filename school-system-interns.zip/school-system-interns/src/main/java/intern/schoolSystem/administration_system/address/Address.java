package intern.schoolSystem.administration_system.address;

public class Address {
    private String postcode;
    private String streetName;
    private int flatNo;

    public Address(String postcode, String streetName, int flatNo) {
        this.postcode = postcode;
        this.streetName = streetName;
        this.flatNo = flatNo;
    }

    public static Address valueOf(String address) {
        String[] split = address.split(",");
        return new Address(split[0], split[1], Integer.parseInt(split[2]));
    }

    @Override
    public String toString() {
        return "postcode='" + postcode + '\'' +
                ", streetName='" + streetName + '\'' +
                ", flatNo=" + flatNo +
                '}';
    }
}
