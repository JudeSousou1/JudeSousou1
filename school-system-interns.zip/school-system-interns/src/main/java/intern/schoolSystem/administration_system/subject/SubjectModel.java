package intern.schoolSystem.administration_system.subject;


public class SubjectModel {

    public void registerSubject(Subject subject) {

    }

    public void deleteSubject(int subjectID) {

    }


    public void updateSubjectDetails(int subjectID, String name, String teacherName) {

    }

}
