package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.address.Address;
import intern.schoolSystem.administration_system.subject.Subject;
import intern.schoolSystem.administration_system.student.Student;


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import static intern.schoolSystem.administration_system.student.Student.getStudentById;

public class StudentEditServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String schoolName = request.getParameter("schoolName");
        int id = Integer.parseInt(request.getParameter("id"));
        int age = Integer.parseInt(request.getParameter("age"));

        Address address = Address.valueOf(request.getParameter("address"));

        Student student = getStudentById(id);

        assert student != null;
        student.editStudentInfo(id, name, age, schoolName, address);
        request.getRequestDispatcher("StudentEdit.jsp").forward(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
