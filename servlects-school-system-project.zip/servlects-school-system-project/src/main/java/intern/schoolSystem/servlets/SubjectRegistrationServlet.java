package intern.schoolSystem.servlets;

import intern.schoolSystem.administration_system.subject.Subject;
import intern.schoolSystem.administration_system.subject.SubjectModel;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;


public class SubjectRegistrationServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String subjectName = request.getParameter("SubjectName");
        String teacherName = request.getParameter("nameTeacher");
        String subjectId = request.getParameter("idStudent");
        String studentCount = request.getParameter("Studentcount");
        System.out.println(subjectId);
        System.out.println(studentCount);
        if (subjectId != null && !subjectId.equals("")) {
            Subject subject = new Subject(subjectName, teacherName, Integer.parseInt(subjectId), Integer.parseInt(studentCount));
            Subject.addSubject(Subject.valueOf(subjectName));

        }
        request.getRequestDispatcher("SubjectRegistration.jsp").forward(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
