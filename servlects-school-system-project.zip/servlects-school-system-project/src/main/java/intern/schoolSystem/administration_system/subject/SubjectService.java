package intern.schoolSystem.administration_system.subject;

public interface SubjectService {
    public void SubjectServiceImpl();
}
