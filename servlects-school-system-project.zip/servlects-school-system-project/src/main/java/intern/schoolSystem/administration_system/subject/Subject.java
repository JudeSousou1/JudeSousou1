package intern.schoolSystem.administration_system.subject;

import intern.schoolSystem.administration_system.DuplicateIdException;
import intern.schoolSystem.administration_system.RecordNotFoundException;
import intern.schoolSystem.administration_system.student.Student;

import java.util.ArrayList;

public class Subject {
    private String name;
    private String teacherName;
    private int id;
    private int studentCount;
    private static ArrayList<Subject> subjects = new ArrayList<Subject>();

    public Subject(String name, String teacherName, int id, int studentCount) {
        this.name = name;
        this.teacherName = teacherName;
        this.id = id;
        this.studentCount = studentCount;
    }

    public static Subject getSubjectById(int id){
        for (Subject s : subjects){
            if (s.getId() == id){
                return s;
            }
        }
        return null;
    }

    public static ArrayList<Subject> getSubjects() {
        return subjects;
    }

    public static Subject valueOf(String s) {
        for (Subject subject : subjects) {
            if (subject.getName().equals(s)) {
                return subject;
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStudentCount() {
        return studentCount;
    }

    public void setStudentCount(int studentCount) {
        this.studentCount = studentCount;
    }

    public void printInfo(){
        System.out.println("Name: " + name);
        System.out.println("Teacher: " + teacherName);
        System.out.println("Id: " + id);
        System.out.println("StudentCount: " + studentCount);
    }

    public static void addSubject(Subject subject){
        for (Subject s : subjects){
            if(s.getId() == subject.getId()){
                throw new DuplicateIdException("Id already exists");
            }
        }
        subjects.add(subject);
    }

    public void editSubjectInfo(String name, int id, int studentCount, String teacherName){
        boolean found = false;
        for (Subject s : subjects){
            if (s.getId() == id){
                s.setName(name);
                s.setTeacherName(teacherName);
                s.setStudentCount(studentCount);
                found = true;
            }
        }
        if(!found){
            throw new RecordNotFoundException("Record does not exist");
        }
    }

    public static void removeSubject(Subject subject){
        boolean found = false;
        for (int i =0; i<subjects.size(); i++){
            if (subjects.get(i).getId() == subject.getId()){
                subjects.remove(i);
                found = true;
            }
        }
        if(!found){
            throw new RecordNotFoundException("Record does not exist");
        }
    }

    @Override
    public String toString() {
        return "Subject{" +
                "name='" + name + '\'' +
                ", teacherName='" + teacherName + '\'' +
                ", id=" + id +
                ", studentCount=" + studentCount +
                '}';
    }
}
