package intern.schoolSystem.administration_system.subject;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SubjectTest {

    @Test
    void getSubjectById() {
        Subject subject1 = new Subject("Math", "Julie", 1, 20);
        Subject.addSubject(subject1);
        assertEquals(subject1, Subject.getSubjectById(subject1.getId()));
    }

    @Test
    void addSubject() {
        Subject subject1 = new Subject("French", "Luke", 3, 20);
        Subject.addSubject(subject1);
        assertTrue(Subject.getSubjects().contains(subject1));
    }

    @Test
    void editSubjectInfo() {
        Subject subject1 = new Subject("English", "Kira", 9, 17);
        Subject.addSubject(subject1);
        subject1.editSubjectInfo("Science", 9, 25, "Polin" );
    }

    @Test
    void removeSubject() {
        Subject subject1 = new Subject("Arabic", "Marc", 5, 17);
        Subject.addSubject(subject1);
        Subject.removeSubject(subject1);
        assertFalse(Subject.getSubjects().contains(subject1));
    }
}