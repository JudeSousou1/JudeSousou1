package intern.schoolSystem.administration_system.student;

import intern.schoolSystem.administration_system.DuplicateIdException;
import intern.schoolSystem.administration_system.address.Address;
import intern.schoolSystem.administration_system.subject.Subject;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class StudentTest {

    @Test
    void addStudent() {
        Address newAddress = new Address("L10191", "street 1", 90);
        ArrayList<Subject> subjects = new ArrayList<Subject>();
        ArrayList<Student> students = new ArrayList<>();
        Student student1 = new Student("John Doe", 17, "DBS", 15, newAddress, subjects);
        students.add(student1);
        assertTrue(students.contains(student1));
    }

    @Test
    void addSubjectToStudent() {
        Address newAddress = new Address("L10191", "street 1", 90);
        ArrayList<Subject> subjects = new ArrayList<Subject>();
        Student student1 = new Student("John Doe", 17, "DBS", 15, newAddress, subjects);
        Subject subject = new Subject("Math", "Julie Smith", 129, 20);
        student1.addSubjectToStudent(subject);
        assertTrue(subjects.contains(subject));
    }


    @Test
    void editStudentInfo() {
        Address newAddress = new Address("L10191", "street 1", 90);
        Address newAddress2 = new Address("Hk1902", "street 2", 23);
        ArrayList<Subject> subjects = new ArrayList<Subject>();
        ArrayList<Student> students = new ArrayList<Student>();
        Subject subject = new Subject("Math", "Julie Smith", 129, 20);
        Student student1 = new Student("John Doe", 17, "DBS", 15, newAddress, subjects);
        student1.addSubjectToStudent(subject);
        Student.addStudent(student1);
        student1.editStudentInfo(17, "Jason", 19, "DAA", newAddress2);
        assertTrue(student1.getName().equals("Jason"));
        assertTrue(student1.getAddress().equals(newAddress2));
        assertTrue(student1.getAge()==19);
        assertTrue(student1.getSchoolName().equals("DAA"));
    }

    @Test
    void getStudentById() {
        Address newAddress = new Address("L10191", "street 1", 90);
        ArrayList<Subject> subjects = new ArrayList<Subject>();
        ArrayList<Student> students = new ArrayList<>();
        Student student1 = new Student("John Doe", 19, "DBS", 15, newAddress, subjects);
        Student.addStudent(student1);
        Student student = Student.getStudentById(student1.getId());
        assertTrue(student.getName().equals("John Doe"));
    }

    @Test
    void removeStudent() {
        Address newAddress = new Address("L10191", "street 1", 90);
        ArrayList<Subject> subjects = new ArrayList<Subject>();
        Student student1 = new Student("John Doe", 17, "DBS", 15, newAddress, subjects);
        Student.addStudent(student1);
        Student.removeStudent(student1.getId());
        assertFalse(student1.getStudents().contains(student1));
    }
}