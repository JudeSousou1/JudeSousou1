import org.junit.Test;

public class fileTest {

    @Test
    public void parsingTest() {

    }

    @Test
    public void dataComparisonTest(){

    }

    @Test
    public void CSVgenerationTest(){

    }
}
