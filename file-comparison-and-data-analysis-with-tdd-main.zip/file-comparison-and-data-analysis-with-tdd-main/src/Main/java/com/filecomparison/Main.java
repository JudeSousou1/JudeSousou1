package com.filecomparison;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {
    public static ArrayList<String> parseXML(String filePath) throws ParserConfigurationException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(filePath);
            NodeList list = doc.getElementsByTagName("data");
            ArrayList<String> persons = new ArrayList<String>();
            String id = null;
            String name = null;
            String age = null;
            for (int i = 0; i < list.getLength(); i++) {
                Node p = list.item(i);
                NodeList childNodes = p.getChildNodes();
                for (int k = 0; k < childNodes.getLength(); k++) {
                    if (childNodes.item(k).getNodeType() == Node.ELEMENT_NODE) {
                        Element e = (Element) childNodes.item(k);
                        if (e.getTagName().equals("person")) {
                            NodeList childPersons = e.getChildNodes();
                            for (int j = 0; j < childPersons.getLength(); j++) {
                                if (childPersons.item(j).getNodeType() == Node.ELEMENT_NODE) {
                                    Element ePerson = (Element) childPersons.item(j);
                                    if (ePerson.getTagName().equals("id")) {
                                        id = ePerson.getTextContent();
                                    }
                                    if (ePerson.getTagName().equals("name")) {
                                        name = ePerson.getTextContent();
                                    }
                                    if (ePerson.getTagName().equals("age")) {
                                        age = ePerson.getTextContent();
                                    }
                                }
                            }
                            String info = id + ";" + name + ";" + age;
                            persons.add(info);
                        }
                    }
                }

            }
            return persons;
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public static ArrayList<String> parseJSON(String filePath) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        FileReader reader = new FileReader(filePath);
        JSONArray jsonArray = new JSONArray();


        try {
            Object obj = parser.parse(reader);
            jsonArray.add(obj);
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<String> list = new ArrayList<String>();
        for (int i = 0; i < jsonArray.size(); i++) {
            list.add(jsonArray.get(i).toString());
        }

        return list;
    }

    public static ArrayList<String> convertArray(String s) throws IOException, ParseException {
        ArrayList<String> list = new ArrayList<String>();
        try {
            // Parse the JSON string
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(s);

            // Extract elements from the array
            JSONObject jsonObject = (JSONObject) jsonArray.get(0);
            JSONArray peopleArray = (JSONArray) jsonObject.get("people");

            // Iterate through each person's details
            for (Object personObj : peopleArray) {
                JSONObject person = (JSONObject) personObj;
                String name = (String) person.get("name");
                Long id = (Long) person.get("id");
                Long age = (Long) person.get("age");


                String k = id + ";" + name + ";" + age;
                list.add(k);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return list;
    }


    public static void compareData(List<String> data1, List<String> data2) throws IOException {
        String temp = null;
        String[] splitData1;
        String[] splitData2;
        ArrayList<String> mismatchedData = new ArrayList<String>();
        ArrayList<String> matchedData = new ArrayList<String>();
        ArrayList<String> missingData = new ArrayList<String>();

        int k = 0;
        for (int i = 0; i < data1.size(); i++) {
            temp = data1.get(i);
            splitData1 = temp.split(";");

            splitData2 = data2.get(k).split(";");
            if (splitData1[0].equals(splitData2[0]) && splitData1[1].equals(splitData2[1]) && splitData1[2].equals(splitData2[2])) {
                System.out.println("matched");
                System.out.println(temp);
                matchedData.add(temp);
            } else if (splitData1[1].equals(splitData2[1])) {
                if (!splitData1[0].equals(splitData2[0]) || !splitData1[2].equals(splitData2[2])) {
                    System.out.println("mismatched");
                    System.out.println(temp);
                    System.out.println(data2.get(k));
                    mismatchedData.add(temp);
                    mismatchedData.add(data2.get(k));
                }
            } else {
                System.out.println("Missing");
                System.out.println(temp);
                System.out.println(data2.get(k));
                missingData.add(temp);
            }
            k++;
        }
        generateCSV("matched.csv", matchedData);
        generateCSV("mismatched.csv", mismatchedData);
        generateCSV("missing.csv", missingData);

    }

    public static void generateCSV(String filePath, ArrayList<String> data) throws IOException {
        FileWriter fw = new FileWriter(filePath);
        for (int i = 0; i < data.size(); i++) {
            fw.write(data.get(i) + "\n");
        }
        fw.close();
    }
    public static void main(String[] args) throws ParserConfigurationException, IOException, ParseException {
        ArrayList<String> s = parseJSON("data.json");
        String j = s.toString();
        System.out.println(convertArray(j));

        ArrayList<String> k = parseXML("data.xml");
        System.out.println(k);

        compareData(convertArray(String.valueOf(s)), k);
    }
}
