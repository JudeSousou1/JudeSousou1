package com.filecomparison;

import java.io.IOException;
import java.util.ArrayList;
import java.io.FileWriter;

public class CSVGenerator {

    public static void generateCSV(String filePath, ArrayList<String> data) throws IOException {
        FileWriter fw = new FileWriter(filePath);
        for (int i = 0; i < data.size(); i++) {
            fw.write(data.get(i) + "\n");
        }
        fw.close();
    }

}
