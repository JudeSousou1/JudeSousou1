package com.filecomparison;


import com.sun.org.apache.xpath.internal.operations.String;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FileParser {

    public ArrayList<String> parseXML(String filePath) throws ParserConfigurationException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try{
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(java.lang.String.valueOf(filePath));
            NodeList list = doc.getElementsByTagName("data");
            ArrayList<String> persons = new ArrayList<String>();
            java.lang.String id = null;
            java.lang.String name = null;
            java.lang.String age = null;
            for (int i = 0; i < list.getLength(); i++) {
                Node p = list.item(i);
                NodeList childNodes = p.getChildNodes();
                for (int k = 0; k < childNodes.getLength(); k++) {
                    if (childNodes.item(k).getNodeType() == Node.ELEMENT_NODE) {
                        Element e = (Element) childNodes.item(k);
                        if (e.getTagName().equals("person")) {
                            NodeList childPersons = e.getChildNodes();
                            for (int j = 0; j < childPersons.getLength(); j++) {
                                if (childPersons.item(j).getNodeType() == Node.ELEMENT_NODE) {
                                    Element ePerson = (Element) childPersons.item(j);
                                    if (ePerson.getTagName().equals("id")) {
                                        id = ePerson.getTextContent();
                                    }
                                    if (ePerson.getTagName().equals("name")) {
                                        name = ePerson.getTextContent();
                                    }
                                    if (ePerson.getTagName().equals("age")) {
                                        age = ePerson.getTextContent();
                                    }
                                }
                            }
                            java.lang.String info = id + " " + name + " " + age;
                        }
                    }
                }

            }
            return persons;
        }
        catch (ParserConfigurationException e){
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public ArrayList<String> parseJSON(String filePath) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        FileReader reader = new FileReader(java.lang.String.valueOf(filePath));
        JSONArray jsonArray = new JSONArray();

        try  {
            Object obj = parser.parse(reader);
            jsonArray.add(obj);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return jsonArray;
    }
}
