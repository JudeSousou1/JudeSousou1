package com.filecomparison;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.filecomparison.CSVGenerator.generateCSV;

public class DataComparator {
    public void compareData(List<String> data1, List<String> data2) throws IOException {
        String temp = null;
        String[] splitData1;
        String[] splitData2;
        ArrayList<String> mismatchedData = new ArrayList<String>();
        ArrayList<String> matchedData = new ArrayList<String>();
        ArrayList<String> missingData = new ArrayList<String>();

        int k = 0;
        for (int i = 0; i < data1.size(); i++) {
            temp = data1.get(i);
            splitData1 = temp.split(";");

            splitData2 = data2.get(k).split(";");
            if (splitData1[0].equals(splitData2[0]) && splitData1[1].equals(splitData2[1]) && splitData1[2].equals(splitData2[2])) {
                System.out.println("matched");
                System.out.println(temp);
                matchedData.add(temp);
            } else if (splitData1[1].equals(splitData2[1])) {
                if (!splitData1[0].equals(splitData2[0]) || !splitData1[2].equals(splitData2[2])) {
                    System.out.println("mismatched");
                    System.out.println(temp);
                    System.out.println(data2.get(k));
                    mismatchedData.add(temp);
                    mismatchedData.add(data2.get(k));
                }
            } else {
                System.out.println("Missing");
                System.out.println(temp);
                System.out.println(data2.get(k));
                missingData.add(temp);
            }
            k++;
        }
        generateCSV("matched.csv", matchedData);
        generateCSV("mismatched.csv", mismatchedData);
        generateCSV("missing.csv", missingData);
    }

}
